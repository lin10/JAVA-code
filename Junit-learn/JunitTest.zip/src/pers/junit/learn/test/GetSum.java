package pers.junit.learn.test;

public class GetSum {
	public static int sum(int s1, int s2){
		System.out.println("��ֵ��"+s1+" + "+s2);
		return s1+s2;
	}
}
