package pers.junit.learn.test;
import java.util.Arrays;
public class Code {
	public String[] codeList(){
		String[] codelist = {"java","php","Python"};
	    System.out.println("������ԣ�"+Arrays.toString(codelist));
	    return codelist;
	}
    
}
