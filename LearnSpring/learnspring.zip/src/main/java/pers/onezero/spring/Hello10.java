package pers.onezero.spring;

public class Hello10 {
	private String name;
	
	public void setName(String name){
		this.name = name;
	}
	
	public void printName(){
		System.out.println("Spring:Hello:"+name);
	}
}
